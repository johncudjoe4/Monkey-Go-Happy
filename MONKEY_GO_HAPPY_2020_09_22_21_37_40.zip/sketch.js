var Monkey, Monkey_running, Monkey_collided;
var ground, groundInvisiable;
var bananaGroup, banana;
var obstacleGroup, obstacle;

function preload() {
  backImage=loadImage("jungle.jpg");
Monkey_running=loadAnimation("Monkey_01.png","Monkey_02.png","Monkey_03.png","Monkey_04.png","Monkey_05.png","Monkey_06.png","Monkey_07.png","Monkey_08.png","Monkey_09.png","Monkey_10.png                                                                                                                            ");
  
  
  bananaImage = loadImage("banana.png");
  obstacleImage = loadImage("stone.png");
  
}

function setup(){
  createCanvas(600,300);
  
 Monkey = createSprite(100,140,20,50);
 Monkey.addAnimation("Monkey", Monkey_running);
 Monkey.scale = 0.1;
  
 banana = createSprite(200,130); 
  
 obstacle = createSprite(200,110);  

 ground = createSprite(380,150);
 ground.velocityX = -4;
  ground.x=ground.width/2; 
  
 groundInvisable = createSprite(600,140);

var bananaGroup = new Group();
var obstacleGroup = new Group();  

  
}

var Score = 0;

function draw() {
 background(255);
 if(keyDown("space")){
    Monkey.velocityY = -12 ;
    }
 Monkey.velocityY = Monkey.velocityY + 0.8;
 if (ground.x < 0){
      ground.x = ground.width/2;
    }
switch(Score){
  case 10: Monkey.scale=0.12;
        break;
  case 20: Monkey.scale=0.14;
        break;
  case 30: Monkey.scale=0.16;
        break;
  case 30: Monkey.scale=0.18;
        break;
  default: break;
}
  
 stroke("black");
 textSize(20);
 fill("white");
 Score = Math.ceil(frameCount/frameRate);
 text("Score:" +Score, 500, 50);
 spawnObstacle();
 spawnBanana();
 Monkey.collide(ground);
 drawSprites();
}

function spawnBanana() {
  if (frameCount % 80 === 0) {
    banana.addAnimation("Banana");
    banana.velocityX = -4;
    banana.y = randomNumber(120, 200);
    banana.scale = 0.05;
    banana.lifetime = 150;
    bananaGroup.add(banana);
  }

}

function spawnObstacle() {
  if (frameCount % 300 === 0) {
    obstacle.addAnimation("Stone");
    obstacle.velocityX = -4;
    obstacle.scale = 0.15;
    obstacleGroup.add(obstacle);
  }

}


  
